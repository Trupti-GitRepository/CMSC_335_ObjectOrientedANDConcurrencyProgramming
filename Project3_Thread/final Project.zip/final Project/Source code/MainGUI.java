
import java.awt.Dimension;

import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Instant;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * This class displays the Traffic signal GUI, has main methods and starts car
 * and signal thread.
 * 
 * @author Trupti Thakur
 *
 */
public class MainGUI extends JFrame implements ActionListener {

	JLabel lb1, lb2, timeLabel; // Labels
	JTextField  jtf; 
	static JTextField displaySignal1, displaySignal2, displaySignal3;// TextFields
	static JTextField car11, car22, car33;
	static JTextField carSpeed1, carSpeed2, carSpeed3;

	// JButtons to start, pause, and stop
	private JButton start, pause, stop, conti;

	RoadSignal s1, s2, s3;
	//Car c1,c2,c3;

	Thread signal1, signal2, signal3;
	Thread clock;
	Thread carA, carB, carC;
	
	
	
	public MainGUI() {

		// Adding components on the frame
		lb1 = new JLabel("Traffic Signal GUI");
		lb2 = new JLabel("Click the Start button to begin simulation");

		start = new JButton("Start");
		pause = new JButton("Pause");
		conti = new JButton("Continue");
		stop = new JButton("Stop");

		displaySignal1 = new JTextField(6);
		displaySignal2 = new JTextField(6);
		displaySignal3 = new JTextField(6);

		car11 = new JTextField(6);
		car22 = new JTextField(6);
		car33 = new JTextField(6);

		carSpeed1 = new JTextField(6);
		carSpeed2 = new JTextField(6);
		carSpeed3 = new JTextField(6);

		// Create a text field.
		jtf = new JTextField(5);
		/*
		 * start.addActionListener(this); stop.addActionListener(this);
		 */
		timeLabel = new JLabel("Current time: ");

		JLabel signalLbelA = new JLabel("Signal A: ");
		JLabel signalLbelB = new JLabel("Signal B: ");
		JLabel signalLbelC = new JLabel("Signal C: ");

		JLabel carLbelA = new JLabel("Car A: ");
		JLabel carLbelB = new JLabel("Car B: ");
		JLabel carLbelC = new JLabel("Car C: ");

		JPanel dataPanel = new JPanel();

		// GUI Layout
		GroupLayout layout = new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);

		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		// start horizontal

		layout.setHorizontalGroup(layout.createSequentialGroup().addContainerGap(30, 30) // Container gap on left side
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(lb1).addComponent(lb2)
						.addGap(20, 20, 20)
						.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addGroup(layout.createSequentialGroup().addComponent(timeLabel).addComponent(jtf)))
						.addGap(20, 20, 20)
						.addGroup(layout.createParallelGroup(GroupLayout.Alignment.CENTER)
								.addGroup(layout.createSequentialGroup().addComponent(start).addComponent(pause)
										.addComponent(conti).addComponent(stop)))
						// ===============
						.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addGroup(layout.createSequentialGroup().addComponent(signalLbelA)
										.addComponent(displaySignal1).addGap(20, 20, 20).addContainerGap(20, 20)
										.addComponent(signalLbelB).addComponent(displaySignal2).addGap(20, 20, 20)
										.addContainerGap(20, 20).addComponent(signalLbelC).addComponent(displaySignal3))
								// .addComponent(dataPanel)
								.addGroup(layout.createSequentialGroup().addComponent(carLbelA).addComponent(car11)
										.addComponent(carSpeed1).addGap(20, 20, 20).addContainerGap(20, 20)
										.addComponent(carLbelB).addComponent(car22).addComponent(carSpeed2)
										.addGap(20, 20, 20).addContainerGap(20, 20).addComponent(carLbelC)
										.addComponent(car33).addComponent(carSpeed3))

						)).addContainerGap(30, 30) // Container gap on right side
		);

		layout.setVerticalGroup(layout.createSequentialGroup()
				.addGroup(layout.createSequentialGroup().addComponent(lb1).addComponent(lb2)).addGap(20, 20, 20)
				.addGroup(layout
						.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(timeLabel).addComponent(jtf))
				.addGap(20, 20, 20)
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(start)
						.addComponent(pause).addComponent(conti).addComponent(stop))
				.addGap(20, 20, 20)
				// =================
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(signalLbelA)
						.addGap(20, 20, 20).addComponent(displaySignal1).addComponent(signalLbelB)
						.addComponent(displaySignal2).addGap(20, 20, 20).addComponent(signalLbelC)
						.addComponent(displaySignal3))
				.addGap(20, 20, 20)
				// .addComponent(dataPanel)
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(carLbelA)
						.addGap(20, 20, 20).addComponent(car11).addComponent(carSpeed1).addComponent(carLbelB)
						.addComponent(car22).addComponent(carSpeed2).addGap(20, 20, 20).addComponent(carLbelC)
						.addComponent(car33).addComponent(carSpeed3).addGap(20, 20, 20)

						.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addGap(20, 20, 20))
						.addGap(20, 20, 20)));
		// End vertical

		start.addActionListener(this);
		stop.addActionListener(this);
		pause.addActionListener(this);
		conti.addActionListener(this);
		pack();
		setSize(700, 400);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	
	
	
	// This method starts clock
	public void createAndStartClock() {
		this.clock = new Thread(new Runnable() {
			private volatile boolean stop = false;

			@Override
			public void run() {
				while (!stop) {
					jtf.setText(Instant.now().toString());
					try {
					//	TimeUnit.SECONDS.sleep(1);
						TimeUnit.MILLISECONDS.sleep(1000);
						
					} catch (InterruptedException e) {
						stop = true;
						System.out.println("Clock Interrupted.. ");
					}
				}
			}
		});
		clock.start();
	}

	//This method creates and starts traffic signals , creates threads of the signals 
	public synchronized void createAndStartSignal() throws InterruptedException {
		this.s1 = new RoadSignal(1000, "Signal_1", displaySignal1);
		this.s2 = new RoadSignal(1200, "Signal_2", displaySignal2);
		this.s3 = new RoadSignal(2400, "Signal_3", displaySignal3);

		signal1 = new Thread(s1);
		signal2 = new Thread(s2);
		signal3 = new Thread(s3);
		signal1.start();
	
		signal2.start();
	//	TimeUnit.SECONDS.sleep(1);
		signal3.start();
		TimeUnit.SECONDS.sleep(1);
	}

	
	//This method creates car objects and starts car's Threads
	public synchronized void carStarts(RoadSignal s1, RoadSignal s2, RoadSignal s3) throws InterruptedException {
		Car c1 = new Car("Car A", 400,70, car11, carSpeed1, s1, s2, s3);
		Car c2 = new Car("Car B", 1000,50, car22, carSpeed2, s1, s2, s3);
		Car c3 = new Car("Car C", 1200,85,car33, carSpeed3, s1, s2, s3);

		carA = new Thread(c1);
		carB = new Thread(c2);
		carC = new Thread(c3);

		carA.start();
		
		carB.start();
	//	TimeUnit.SECONDS.sleep(1);
		carC.start();
		//TimeUnit.SECONDS.sleep(1);
	}
	
	
	
	public void stopSignalsandCars() throws InterruptedException {
		clock.sleep(10000);
		signal1.sleep(10000);
		signal2.sleep(10000);
		signal3.sleep(10000);
		carA.sleep(10000);
		carB.sleep(10000);
		carC.sleep(10000);
		
		
	}
	
	

	//Action event
	
	public void actionPerformed(ActionEvent e) {

		if (e.getActionCommand().equals("Start")) {
				createAndStartClock();
				try {
					createAndStartSignal();
					carStarts(this.s1, this.s2, this.s3);
				} catch (Exception ex) {
				}
		}
		if (e.getActionCommand().equals("Stop")) {
				
			clock.interrupt();
			signal1.interrupt();
			signal2.interrupt();
			signal3.interrupt();
			carA.interrupt();
			carB.interrupt();
			carC.interrupt();
			
			System.exit(0);
			
			
		}
		if (e.getActionCommand().equals("Pause")) {
			
						
			clock.interrupt();
			signal1.interrupt();
			signal2.interrupt();
			signal3.interrupt();
			carA.interrupt();
			carB.interrupt();
			carC.interrupt();
			
			System.out.println(" Simpulation is paused......");
			
			
			
		}
		
		if (e.getActionCommand().equals("Continue")) {
			createAndStartClock();
			try {
				createAndStartSignal();
				carStarts(this.s1, this.s2, this.s3);
			} catch (Exception ex) {
			}
			
			System.out.println(" Simpulation is continue......");
		}
	}

	public static void main(String[] args) {
		MainGUI test = new MainGUI();

	}
}