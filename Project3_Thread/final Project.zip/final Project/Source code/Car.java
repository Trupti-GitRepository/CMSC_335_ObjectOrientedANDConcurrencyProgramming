import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JTextField;

//This class creates a CAR object, implements a Runnable interface

public class Car implements Runnable {
	
	private String carName;
	private volatile int carXPosition;
	//private int signalPosition=1000;
	private int yPosition=0;
	private int speed;
	private boolean MAX_SPEED=false;
	private JTextField jtfPos, jtfSpeed ;
	
	private boolean isRunning=true;
	
	TrafficLightColor signalColor;
	
	
	RoadSignal s1,s2,s3;
	
	enum TrafficLightColor {  
		  RED, GREEN, YELLOW 
		} 
	
	/**
	 * 
	 * @param name name of the car 
	 * @param xpos x-coordinates
	 * @param speed of the car
	 * @param jtfPos   text field to display car's current position
	 * @param jtfSpeed text field  to display car's current speed
	 * @param s1   Signal_1 object reference 
	 * @param s2	Signal_2 object reference 
	 * @param s3	Signal_3 object reference 
	 */
	
    public Car(String name, int xpos,int speed, JTextField jtfPos, JTextField jtfSpeed,RoadSignal s1, RoadSignal s2, RoadSignal s3) {
		this.carName = name;
		this.carXPosition = xpos;
		this.speed = speed;
		this.jtfPos=jtfPos;
		this.jtfSpeed=jtfSpeed;
		this.s1=s1;
		this.s2=s2;
		this.s3=s3;
		/*s2=new RoadSignal();
		s3=new RoadSignal();*/
	}
    
    //This method returns car current xposition.
   public  int getCarPosition() {
	   
        return carXPosition;
    }
   
   
   //This method retuns car speed
  public int getSpeed() { 
	 					
		return speed ;
  }
  
  //REtuns the name of the car, helps to identify which thread is running
   public String getCarName() {
	   return carName;
   }
   
   public void stopCar() {
	   Thread.interrupted();
	   this.carXPosition=getCarPosition();
	   this.speed=0;
   }
  
   
   
	//Run method
	@Override
	public void run() {
		
		
		
		//check the x position matches any signal position and see the signal status and decide car speed
		
		/*while(isRunning) {
			if((s1.getCurrentSignalColor().equals("RED") && s1.getSignalPosition()==this.carXPosition)
					||(s2.getCurrentSignalColor().equals("RED") && s2.getSignalPosition()==this.carXPosition)
					||(s3.getCurrentSignalColor().equals("RED") && s3.getSignalPosition()==this.carXPosition))
			{
						try {
							TimeUnit.SECONDS.sleep(4);
						} catch (InterruptedException e) {
							//e.printStackTrace();
						}
						//this.carXPosition+=50;    // 50 m / s
						this.speed = 0 ;
						jtfPos.setText(carXPosition+" m");
						jtfSpeed.setText(speed +" km/h");
						System.out.println(this.getCarName()+" stopped.");
					continue;
			}
				try {
					TimeUnit.SECONDS.sleep(1);
				} catch (InterruptedException e) {
					//e.printStackTrace();
				}
			this.carXPosition+=50;    // 50 m / s
			this.speed += 2 ;
			jtfPos.setText(this.carXPosition+" m");
			jtfSpeed.setText(this.speed +" km/h");
		}	
		*/
		
		
		
		while(isRunning) {
			jtfPos.setText(this.carXPosition +" m");
			jtfSpeed.setText(this.speed +" km/h");
			if((s1.getCurrentSignalColor().equals("RED") && this.carXPosition==s1.getSignalPosition()))
			{
				try {
					TimeUnit.SECONDS.sleep(4);
				} catch (InterruptedException e) {
					//e.printStackTrace();
				}
				this.carXPosition= 1000;    // 50 m / s
				this.speed = 0 ;
				jtfPos.setText(carXPosition+" m");
				jtfSpeed.setText(speed +" km/h");
				System.out.println(this.getCarName()+" stopped at "+ s1.getName());
			continue;
				
			}else if((s2.getCurrentSignalColor().equals("RED") && s2.getSignalPosition()==this.carXPosition))
			{
				try {
					TimeUnit.SECONDS.sleep(4);
				} catch (InterruptedException e) {
					//e.printStackTrace();
				}
				this.carXPosition =2000;    // 50 m / s
				this.speed = 0 ;
				jtfPos.setText(carXPosition+" m");
				jtfSpeed.setText(speed +" km/h");
				System.out.println(this.getCarName()+" stopped at "+ s2.getName() );	
				continue;
			} else if((s3.getCurrentSignalColor().equals("RED") && s3.getSignalPosition()==this.carXPosition)){
				
				try {
					TimeUnit.SECONDS.sleep(4);
				} catch (InterruptedException e) {
					//e.printStackTrace();
				}
					
				this.carXPosition=3000;    // 50 m / s
				this.speed = 0 ;
				jtfPos.setText(carXPosition+" m");
				jtfSpeed.setText(speed +" km/h");
				System.out.println(this.getCarName()+" stopped "+ s3.getName());
				continue;
					
			}
			
					
			
				try {
					TimeUnit.SECONDS.sleep(1);
				} catch (InterruptedException e) {
					//e.printStackTrace();
				}
			this.carXPosition+=50;    // 50 m / s
			while(!MAX_SPEED) {
				this.speed+=10;
				if(this.speed==180) {      //Max-speed is 180 km/hr
					speed=180;
					MAX_SPEED=true;
				}
			}
			
			
			
			
			jtfPos.setText(this.carXPosition+" m");
			jtfSpeed.setText(this.speed +" km/h");
		}	
		
		
		//sleep if required
		//increase x coordinate
	}

}
