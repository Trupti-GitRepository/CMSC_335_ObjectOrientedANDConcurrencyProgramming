import java.awt.Color;
import java.util.concurrent.TimeUnit;

import javax.swing.JLabel;
import javax.swing.JTextField;

//This class creates roadsignals object provides real trafficLight scenario., 

public class RoadSignal implements Runnable{
	private boolean stop;
	private int x ;
	private int y = 0;
	private volatile String color = "RED";
	private String name;
	//private JLabel label;
	private JTextField label;
	
/**
 * 
 * @param x  signal position
 * @param name  name of the signal
 * @param label  label to display signalcolor
 */
	public RoadSignal(int x, String name, JTextField label) {
		this.x = x;
		this.name = name;
		this.label = label;
	}
	
	/**
	 * Returns signalColor
	 * @return signalColor
	 */
	public String signalColor() {
		return color;
	}
	
	/**
	 * Returns signal position
	 * @return SignalPosition
	 */
	public int getSignalPosition() {
		return x;
	}
	
	/**
	 * Returns name of the signal
	 * @return name of the signal 
	 */
	public String getName() {
		return name;
	}
	
	public JTextField getText() {
		return label;
	}
	
	
	/**
	 * if colore is "GREEN", change it to "Yellow", Yellow--> RED, RED--->GREEN
	 * @return
	 */
	public String getCurrentSignalColor() {
		this.color = this.color.equals("GREEN")?"YELLOW":this.color.equals("YELLOW")?"RED":this.color.equals("RED")?"GREEN":this.color;
		
		return this.color;
	}
	
	
	@Override
	public void run() {
		while(!stop) {
			try {
			getCurrentSignalColor()	;	
			/*this.color = this.color.equals("GREEN")?"YELLOW":this.color.equals("YELLOW")?"RED":this.color.equals("RED")?"GREEN":this.color;
				label.setText(this.color);*/
				if(this.color.equalsIgnoreCase("GREEN")) {
					label.setForeground(new Color(0,200,10)); //Set font color to green;
					label.setText(this.color);
				}
				
				if(this.color.equalsIgnoreCase("YELLOW")) {
					label.setForeground(new Color(247, 226, 35)); //Set font color to green;
					label.setText(this.color);
				}
				if(this.color.equalsIgnoreCase("RED")) {
					label.setForeground(Color.RED); //Set font color to green;
					label.setText(this.color);
				}
				if(color.equals("GREEN")) {
					TimeUnit.SECONDS.sleep(6);
				}
				if(color.equals("RED")) {
					TimeUnit.SECONDS.sleep(4);
				}else {
					TimeUnit.SECONDS.sleep(3);
				}
			} catch (InterruptedException e) {
				stop=true;
				System.out.println(name + "interrupted..");
			}
			
		}
	}

}
