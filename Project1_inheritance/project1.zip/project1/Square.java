package project1;


import java.io.*;
import java.text.DecimalFormat;
/**
 * This class accepts length and calculates area of the Square, extends TwoDimensionalShape class.
 * @author Trupti Thakur
 *
 */
import java.util.*;

public class Square extends TwoDimensionalShape {
	
	
	public Square(double length) {
		super(length);
	}
	
	/**
	 * getLength method returns Length of the Square
	 * @return Length of the Square.
	 */
	
	public double getlength() {
		return getDim1();
	}
	
	/**
	 * getArea method calculates area of the square
	 * @return area of the square.
	 */

	@Override
	public double getArea() {
		return Math.pow(getlength(),2);
	}
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	/**
	 * toString method
	 * @return A string containing a Square area information.
	 */
	@Override
	public String toString() {
		String str = "Area of Square:  "+ myFormatter.format(getArea())+"\n";
		return str;
		
	}

	
	
}
