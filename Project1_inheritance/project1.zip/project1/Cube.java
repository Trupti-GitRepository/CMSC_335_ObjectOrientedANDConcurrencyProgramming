package project1;

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
/**
 * This class accepts edge and calculates volume of the cube, extends ThreeDimensionalShape class.
 * @author Trupti Thakur
 *
 */

public class Cube extends ThreeDimensionalShape {
	
	
	
	public Cube(double edge) {
		super(edge);
	}
	
	/**
	 * getEdge method returns Edge of the Cone.
	 * @return edge of the cone.
	 */
	
	public double getEdge() {
		return getDim1();
	}
/*
	@Override
	public double getArea() {
		return Math.pow(getEdge(), 2) * 6;
	} */

	/**
	 * Calculates and returns volume of the Cube.
	 */
	@Override
	public double getVolume() {
		return Math.pow(getEdge(), 3) ;
	}
	
	
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	
	/**
	 * toString method
	 * @return A string containing a Cube's volume information.
	 */
	@Override
	public String toString() {
		String str = "Volume of the Cube: "+ myFormatter.format(getVolume())+"\n";
		return str;
		
	}

}
