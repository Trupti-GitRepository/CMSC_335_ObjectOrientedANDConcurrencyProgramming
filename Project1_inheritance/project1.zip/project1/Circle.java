package project1;

import java.text.DecimalFormat;
/**
 * This class accepts radius and calculates area of the Circle, extends TwoDimensionalShape class.
 * @author Trupti Thakur
 *
 */

public class Circle extends TwoDimensionalShape {
	
	/**
	 * Parameterized Constructor accepts radius
	 * @param radius of the circle
	 */
	
	public Circle(double radius) {
		super(radius);
	}
	
/**
 * getRadius method
 * @return dimension of the radius.
 */
	
	private double getRadius() {
		return getDim1();
	}
	
	/**
	 * getArea methods
	 * @return calculated area for the circle.
	 */

	@Override
	public double getArea() {
		return Math.PI * Math.pow(getRadius(),2);	
		
	}
	
	//Format Output
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	/**
	 * toString method
	 * @return A string containing a Circle's Area information.
	 */
	@Override
	public String toString() {
		String str = "Area of the Circle "+ myFormatter.format(getArea());
		return str;
		
	}
	


	
	
	
	
	

}
