package project1;


import java.io.*;
import java.util.*;
/**
 * ThreeDimensionalShape class extends shape class, has volume and provides outlines for other derived classes.
 * @author Trupti Thakur
 *
 */

public abstract class ThreeDimensionalShape extends Shape {
	private double volume;   //// ThreeDimensionalShape has a volume.
	
	public ThreeDimensionalShape() {
		super();

	}
	
	
	/* Constructor accepts one dimension */
	public ThreeDimensionalShape(double dim1) {
		super(dim1);

	}
	
	/* Constructor accepts two dimension */
	public ThreeDimensionalShape(double dim1, double dim2) {
		super(dim1, dim2);

	}
	
	/* Constructor accepts three dimension */
	public ThreeDimensionalShape(double dim1, double dim2, double dim3) {
		super(dim1, dim2, dim3);

	}


	//public abstract double getArea();
	
	//getVolume() method calculates and returns volume of the shape.
	public abstract double getVolume();

	
	

}
