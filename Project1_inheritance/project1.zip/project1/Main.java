package project1;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;

/**
 * Main class takes user input to select the shape from the menu and 
 * find out the area or volume for the selected shape.
 * CMSC_335 Project 1
 * Date: 09/01/2021
 * @author Trupti Thakur. 
 */

import java.util.Scanner;
import java.util.TimeZone;

public class Main {

public static void main(String[] args) {
	
	SimpleDateFormat formatDate = new SimpleDateFormat(
            "dd/MM/yyyy  HH:mm:ss z");
	//Date current_date = new Date();
	formatDate.setTimeZone(TimeZone.getTimeZone("IST"));

	Scanner keybord = new Scanner(System.in);
	System.out.println("*********Welcome to the Java OO Shapes Program **********");
	int input = 0;
	String reply="";
	String cont="";
	char repeat = 0;
	double length, width, height, radius = 0.0;
	
	TwoDimensionalShape r;  
	ThreeDimensionalShape v;
//	boolean isInvalid=false;
		do {
			//Take user input
			System.out.println("\nSelect from the menu below:");
			System.out.println(
					"1. Construct a Circle\r\n" +
					"2. Construct a Rectangle\r\n" 	+
					"3. Construct a Square\r\n" + 
					"4. Construct a Triangle\r\n" + 
					"5. Construct a Sphere\r\n"+
					 "6. Construct a Cube\r\n" + 
					"7. Construct a Cone\r\n" +
					"8. Construct a Cylinder\r\n"+
					"9. Construct a Torus\r\n" +
					"10. Exit the program");
					System.out.print("\n");
					input = keybord.nextInt();
			
		
		switch (input) {
		case (1):
			System.out.println("You have selected Circle");
			System.out.print("What is the radius?");
			length = keybord.nextInt();
			r = new Circle(length);
			System.out.println(r.toString());
			break;
			
		case (2):
			System.out.println("You have selected Rectangle");
			System.out.print("What is the length?");
			length = keybord.nextInt();
			System.out.print("What is the width?");
			width = keybord.nextInt();
			r = new Rectangle(length, width);
			System.out.println(r.toString());
			break;
			
		case (3):
			System.out.println("You have selected Square");
			System.out.print("What is the length?");
			length = keybord.nextInt();
			r = new Square(length);
			System.out.println(r.toString());
			break;
			
		case (4):
			System.out.println("You have selected Triangle");
			System.out.print("What is the baseLength?");
			length = keybord.nextInt();
			System.out.print("What is the height?");
			width = keybord.nextInt();
			r = new Triangle(length, width);
			System.out.println(r.toString());
			break;
			
		case (5):
			System.out.println("You have selected Sphere");
			System.out.print("What is the radius?");
			radius = keybord.nextInt();
			v = new Sphere(radius);
			System.out.print(v.toString());
			break;
			
		case (6):
			System.out.println("You have selected Cube");
			System.out.print("What is the Edge of the Cube?");
			length = keybord.nextInt();
			v = new Cube(length);
			System.out.println(v.toString());
			break;
			
		case (7):
			System.out.println("You have selected Cone");
			System.out.print("What is the radius?");
			radius = keybord.nextInt();
			System.out.print("What is the height?");
			height = keybord.nextInt();
			v = new Cone(radius, height);
			System.out.println(v.toString());
				break;	
			
		case (8):
			System.out.println("You have selected Cylinder");
			System.out.print("What is the radius?");
			radius = keybord.nextInt();
			System.out.print("What is the height?");
			height = keybord.nextInt();
			v = new Cylinder(radius, height);
			System.out.println(v.toString());
				break;	
				
		case (9):
			System.out.println("Torus");
			System.out.println("You have selected Torus");
			System.out.print("What is the minor Radius?");
			radius = keybord.nextInt();
			System.out.print("What is the Major Radius?");
			height = keybord.nextInt();
			v = new Torus(radius,height);
			System.out.println(v.toString());
			break;
		
		case (10):
			System.out.println("Thanks for using the program.");		
			System.out.println(LocalDateTime.now());
			System.exit(0);
			break;
			
		default:
			
			System.out.println("Error ...Invalid Input.");
			keybord = new Scanner(System.in);			
			 
		}
		
		}while(input== 10 || input < 1 || input >10);
		
	}
		

}
