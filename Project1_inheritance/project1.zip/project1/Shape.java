package project1;

/**
 * Shape class is a supperclass, accepts dimensions and provides outlines for
 * other  classes.
 * 
 * @author Trupti Thakur
 *
 */

public abstract class Shape {

	int numberofDimensions;
	private double dim1, dim2, dim3;

	/* No-arg constructor */
	public Shape() {

	}

	/* Constructor accepts one dimension */
	public Shape(double dim1) {
		this.dim1 = dim1;

	}

	/* Constructor accepts two dimension */
	public Shape(double dim1, double dim2) {
		this.dim1 = dim1;
		this.dim2 = dim2;

	}

	/* Constructor accepts three dimension */
	public Shape(double dim1, double dim2, double dim3) {
		this.dim1 = dim1;
		this.dim2 = dim2;
		this.dim3 = dim3;

	}

	public Shape(int numberofDimensions) {
		this.numberofDimensions = numberofDimensions;
	}

	//public abstract void calculateArea();
	
	// methods return dimesions.

	public double getDim1() { 		return dim1; }

	public double getDim2() {		return dim2;	}

	public double getDim3() {	return dim3; }
}