package project1;

import java.io.*;
/**
 * TwoDimensionalShape class extends shape class, has area and provides outlines for other derived classes.
 * @author Trupti Thakur
 *
 */
import java.util.*;

public abstract class TwoDimensionalShape extends Shape {
	protected double area;   // TwoDimensionalShape has a area.
	
	/** Constructor*/
	public TwoDimensionalShape() {
		super();

	}
	
	/* Constructor accepts one dimension */
	public TwoDimensionalShape(double dim1) {
		super(dim1);

	}
	
	/* Constructor accepts two dimension */
	public TwoDimensionalShape(double dim1, double dim2) {
		super(dim1, dim2);

	}
	
	/* Constructor accepts three dimension */
	public TwoDimensionalShape(double dim1, double dim2, double dim3) {
		super(dim1, dim2, dim3);

	}

	public TwoDimensionalShape(int numberofDimensions) {
		super(numberofDimensions);
	}

	

	//public abstract void calculateArea();
	
	
	//getArea() method calculates and returns area of the shape.
	public  abstract double getArea();
	
	
	/**
	 * toString method
	 * @return A string containing a shape area information.
	 */
	public String toString() {
		return String.format("%sArea TwoDimensionalShape: %.2f\n", getArea());
	}
	
	

}
