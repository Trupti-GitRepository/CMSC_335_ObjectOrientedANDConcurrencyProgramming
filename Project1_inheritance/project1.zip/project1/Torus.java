package project1;


import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

/**This class accepts radius  and calculates volume of the Torus in terms radius  extends ThreeDimensionalShape class.
* @author Trupti Thakur */
public class Torus extends ThreeDimensionalShape {
	
	
	public Torus(double minorRadius, double majorRadius) {
		super(minorRadius, majorRadius);
	}
	
	public double getMinorRadius() {
		return getDim1();
	}
	public double getMajorRadius() {
		return getDim2();
	}

	/*@Override
	public double getArea() {
	 return ((2 * Math.PI* getRadius())* (2 * Math.PI* getRadius()));
	}*/

	@Override
	public double getVolume() {
		return ((Math.PI * Math.pow(getMinorRadius(),2))* (2 * Math.PI * getMajorRadius()));
	}
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	@Override
	public String toString() {
		String str = " Volume of the Torus:  "+ myFormatter.format(getVolume())+"\n";
		return str;
		
	}
	
	
	

}
