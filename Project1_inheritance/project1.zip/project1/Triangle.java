package project1;


import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

/**
 * This class accepts base Length and height and calculates
 * area of the Triangle,
 * extends TwoDimensionalShape class
 *  
 * @author Trupti Thakur
 *
 */

public class Triangle extends TwoDimensionalShape {
	
	private double base, height;

	public Triangle(double base, double height) {
		this.base=base;
		this.height= height;
	}
	
	/**
	 * getBase method returns base of the Triangle
	 * @return base of the Triangle.
	 */
	public double getBase() {
		return base;
	}
	
	/**
	 * getHeight method returns height of the Triangle
	 * @return height of the Triangle.
	 */
	
	public double getHeight() {
		return height;
	}
	
	/**
	 * getArea method calculates area of the Triangle
	 * @return area of the Triangle.
	 */
	@Override
	public double getArea() {
		return (getBase()*getHeight()/2);
	}
	
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	/**
	 * toString method
	 * @return A string containing a Triangle area information.
	 */
	@Override
	public String toString() {
		String str = "Area of Triangle:  "+ myFormatter.format(getArea())+"\n";
		return str;
		
	}
	
	

}
