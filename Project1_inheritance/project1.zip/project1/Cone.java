package project1;


import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
/**This class accepts radius and height, calculates volume of the cone extends ThreeDimensionalShape class.
* @author Trupti Thakur */
public class Cone extends ThreeDimensionalShape {
	
	/* Constructor */
	public Cone(double radius, double height) {
		super(radius, height);
	}
	
	/**
	 * getRadius method returns radius of the Cone.
	 * @return radius of the cone
	 */
	public double getRadius() {
		return getDim1();
	}
	
	/**
	 * getHeight method returns radius of the Cone.
	 * @return height of the cone.
	 */
	public double getHeight() {
		return getDim2();
	}

	/*@Override
	public double getArea() {
		return Math.pow(getRadius(), 2) * 6;
	}*/

	/**
	 * Calculates and returns volume of the cone.
	 */
	@Override
	public double getVolume() {
		return (Math.PI * Math.pow(getRadius(), 2) * getHeight()) /3;
	}
	
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	
	
	/**
	 * toString method
	 * @return A string containing a Cone's volume information.
	 */
	
	@Override
	public String toString() {
		String str = "Volume of the Cone:  "+ myFormatter.format(getVolume())+"\n";
		return str;
		
	}
	




}
