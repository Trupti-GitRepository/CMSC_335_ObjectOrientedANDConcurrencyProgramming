package shape_Project2;

import javax.swing.*;

import project2.Torus;

import java.awt.*;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/*This class creats a Jpanel for fram ,accepsts appropriate dimensional parameters and then display that shape in a frame of GUI.
* For 3-D shapes image is loading. */

public class DrawShape extends JPanel {

	private String shape;
	private double dimensions[];

	private int length, height, radius,width , base, side, minorRadius, majorRadius;
	//TriangleShape triangleShape;
	  Polygon poly;

	public DrawShape(String shape, double[] dim) {
		this.shape = shape;
		this.dimensions = dim;
		repaint();

	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		try {
			if (shape.equals("Circle")) {
				radius = (int) dimensions[0];
				
				Circle r = new Circle (dimensions[0]);
				g.setColor(Color.green);
				//g.fillArc(75, 20, radius, radius, 0, 360);
				g.fillOval(75, 20, radius, radius);
			}else if (shape.equals("Square")) {
				side = (int) dimensions[0];
				
				Square r = new Square(dimensions[0]);
				g.setColor(Color.green);
				g.fillRect(75, 20, side, side);
				
			}else if (shape.equals("Triangle")) {
				base = (int) dimensions[0];
				height = (int) dimensions[1];
				Triangle r = new Triangle(dimensions[0], dimensions[1]);
				g.setColor(Color.green);
								
			//	g.drawLine(10, 10, 100, 60);
			 //   g.drawLine(100, 60, 50, 80);
			   // g.drawLine(50, 80, 10, 10);
			    int[] x = { 140, 160, 180, };
			    int[] y = { 80, 10, 80};
			    g.fillPolygon(x, y, 3);
				    
			} else if (shape.equals("Rectangle")) {
				length = (int) dimensions[0];
				width = (int) dimensions[1];
				Rectangle r = new Rectangle(dimensions[0], dimensions[1]);
				g.setColor(Color.green);
				g.fillRect(75, 20, length, width);
			}else 
			{
				Image image = null;

				if (shape.equals("Sphere")) {
					radius = (int) dimensions[0];
					Sphere r=new Sphere (dimensions[0]);
					image = ImageIO.read(new File("sphere.jpg"));

				}
				if (shape.equals("Cube")) {
					radius = (int) dimensions[0];					
					Cube r=new Cube(dimensions[0]);
					image = ImageIO.read(new File("cube.jpg"));

				}
				if (shape.equals("Cone")) {
					radius = (int) dimensions[0];
					height = (int) dimensions[1];
					Cone r=new Cone(dimensions[0],dimensions[1]);

					image = ImageIO.read(new File("cone.jpg"));

				}
				if (shape.equals("Cylinder")) {
					radius = (int) dimensions[0];
					height = (int) dimensions[1];
					Cylinder r=new Cylinder(dimensions[0],dimensions[1]);

					image = ImageIO.read(new File("cylinder.jpg"));

				}
				if (shape.equals("Torus")) {
					radius = (int) dimensions[0];
					height = (int) dimensions[1];
					//Torus r = new Torus(dimensions[0],dimensions[1]);
					
					image = ImageIO.read(new File("torus.jpg"));
					

				}
				g.drawImage(image, 5, 5, null);
			}
		}

		catch (Exception e) {

			JOptionPane.showMessageDialog(this,

					"The image for the selected shape wasn't found!", "Error",

					JOptionPane.ERROR_MESSAGE);
		}

	}
	
	
}
