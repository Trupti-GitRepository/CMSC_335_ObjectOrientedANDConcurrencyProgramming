package shape_Project2;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
/**
 * This class accepts radius and calculates volume of the Sphere, extends ThreeDimensionalShape.
 * @author Trupti Thakur
 *
 */
public class Sphere extends ThreeDimensionalShape {	
	
	public Sphere(double radius) {
		super(radius);
		
	}
	
	/**
	 * getRadius method returns radius of the Sphere
	 * @return returns radius of the Sphere
	 */
	public double getRadius() {
		return getDim1();
	}

	/*@Override
	public double getArea() {
		return (1/3)* Math.PI*Math.pow(getRadius(), 2);
	}
	*/

	/**
	 * getVolume method calculates volume of the Sphere
	 * @return returns volume of the Sphere
	 */
	@Override
	public double getVolume() {
		return ( (Math.PI * Math.pow(getRadius(), 3) * 4)/3);
	}
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	/**
	 * toString method
	 * @return A string containing a Sphere volume information.
	 */
	@Override
	public String toString() {
		String str = "Volume of the Sphere: "+ myFormatter.format(getVolume())+"\n";
		return str;
		
	}

}
