package shape_Project2;

import java.text.DecimalFormat;

/**
 * This class accepts length and width and calculates area of the rectangle, extends TwoDimensionalShape
 * @author Trupti Thakur
 *
 */

public class Rectangle extends TwoDimensionalShape {
	//protected double length, width;
	
	public Rectangle(double length, double width) {
		super(length,width);
	}
	
	
	/*public  Rectangle(double length, double width, int numberOfDimentions) {
		super(numberOfDimentions);
		this.length=length;
		this.width= width;
	}*/
	
	/**
	 * getLength method returns Length of the rectangle
	 * @return Length of the rectangle..
	 */
	
	public double getLength() {
		return getDim1();		
	}
	
	
	/**
	 * getWidth method returns Width of the rectangle
	 * @return width of the rectangle..
	 */
	public double getWidth() {
		return getDim2();
	}
	

	

/*	@Override
	public void calculateArea() {
		this.area=this.getDim1() * this.getDim2();
	}*/
	
	/**
	 * getArea method calculates area of the rectangle
	 * @return area of the rectangle..
	 */
	
	public double getArea() {
		return this.getDim1() * this.getDim2();
		
	}
	
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	/**
	 * toString method
	 * @return A string containing a Rectangle's area information.
	 */
	@Override
	public String toString() {
		String str = "Area of Rectangle:  "+ myFormatter.format(getArea())+"\n";
		return str;
		
	}
	
			
	

}
