package shape_Project2;

import java.awt.BorderLayout;
/**
 *This class allows a user to select a shape from a list of available shapes,
 * enter appropriate dimensional parameters and then display that shape in a frame of GUI.
 * For 3-D shapes image is loading.
 * @author Trupti Thakur
 *
 */
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MainGUI extends JFrame implements ActionListener {

	private JLabel jLab;
	private JPanel shapePanel, rightPanel;
	private String dim1, dim2;
	private double length, height, edge, width, base, side, radius;
	private JRadioButton circle, square, triangle, rectangle, sphere, cube, cone, cylinder, torus;

	public MainGUI() {

		shapePanel = new JPanel();
		rightPanel = new JPanel(new BorderLayout(600, 400));
		setTitle("Draw Shapes.");
		setSize(600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(10, 1));

		jLab = new JLabel("Select any button to draw shape. ");

		// Create radion buttons
		circle = new JRadioButton("Circle");
		square = new JRadioButton("Square");
		triangle = new JRadioButton("Triangle");
		rectangle = new JRadioButton("Rectangle");
		sphere = new JRadioButton("Sphere");
		cube = new JRadioButton("Cube");
		cone = new JRadioButton("Cone");
		cylinder = new JRadioButton("Cylinder");
		torus = new JRadioButton("Torus");

		buttonPanel.add(jLab);
		// Adding buttons in the panel
		buttonPanel.add(circle);
		buttonPanel.add(square);
		buttonPanel.add(triangle);
		buttonPanel.add(rectangle);
		buttonPanel.add(sphere);
		buttonPanel.add(cube);
		buttonPanel.add(cone);
		buttonPanel.add(cylinder);
		buttonPanel.add(torus);

		circle.addActionListener(this);
		square.addActionListener(this);
		triangle.addActionListener(this);
		rectangle.addActionListener(this);
		sphere.addActionListener(this);
		cube.addActionListener(this);
		cone.addActionListener(this);
		cylinder.addActionListener(this);
		torus.addActionListener(this);

		// Define a button group.
		ButtonGroup bg = new ButtonGroup();
		bg.add(circle);
		bg.add(square);
		bg.add(triangle);
		bg.add(rectangle);

		bg.add(sphere);
		bg.add(cube);
		bg.add(cone);

		bg.add(cylinder);
		bg.add(torus);

		add(buttonPanel, BorderLayout.WEST);
		shapePanel.setPreferredSize(new Dimension(600, 500));
		rightPanel.add(shapePanel, BorderLayout.CENTER);

		add(rightPanel, BorderLayout.CENTER);
		
		//pack();
		setVisible(true);
		//setResizable(false);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		String selection = e.getActionCommand();

		if (selection.equals("Circle")) {
			dim1 = JOptionPane.showInputDialog("Enter the radius: ");

			try {
				radius = Double.parseDouble(dim1);
				shapePanel = new DrawShape(selection, new double[] { radius });
				rightPanel.add(shapePanel, BorderLayout.CENTER);
			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}
		} else if (selection.equals("Square")) {
			dim1 = JOptionPane.showInputDialog("Enter the side: ");

			try {
				side = Double.parseDouble(dim1);

				shapePanel = new DrawShape(selection, new double[] { side });
				rightPanel.add(shapePanel, BorderLayout.CENTER);
			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}
		} else if (selection.equals("Triangle")) {
			dim1 = JOptionPane.showInputDialog("Enter the baseLength of the Triangle : ");
			dim2 = JOptionPane.showInputDialog("Enter the Height: ");

			try {
				base = Double.parseDouble(dim1);
				height = Double.parseDouble(dim2);

				shapePanel = new DrawShape(selection, new double[] { base, height });
				rightPanel.add(shapePanel, BorderLayout.CENTER);
			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}
		}

		else if (selection.equals("Rectangle")) {
			dim1 = JOptionPane.showInputDialog("Enter the length: ");
			dim2 = JOptionPane.showInputDialog("Enter the width: ");
			try {
				length = Double.parseDouble(dim1);
				width = Double.parseDouble(dim2);
				shapePanel = new DrawShape(selection, new double[] { width, length });
				rightPanel.add(shapePanel, BorderLayout.CENTER);
			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}

		} else if (selection.equals("Sphere")) {
			dim1 = JOptionPane.showInputDialog("What is the radius of the Sphere?");
			try {
				radius = Double.parseDouble(dim1);
				shapePanel = new DrawShape(selection, new double[] { radius });
				rightPanel.add(shapePanel, BorderLayout.CENTER);

			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}

		} else if (selection.equals("Cube")) {
			dim1 = JOptionPane.showInputDialog("What is the Edge of the Cube?");
			try {
				edge = Double.parseDouble(dim1);
				shapePanel = new DrawShape(selection, new double[] { edge });
				rightPanel.add(shapePanel, BorderLayout.CENTER);

			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}
		} else if (selection.equals("Cone")) {
			dim1 = JOptionPane.showInputDialog("Enter the radius: ");
			dim2 = JOptionPane.showInputDialog("Enter the height: ");
			try {
				radius = Double.parseDouble(dim1);
				height = Double.parseDouble(dim2);
				shapePanel = new DrawShape(selection, new double[] { radius, height });
				rightPanel.add(shapePanel, BorderLayout.CENTER);

			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}
		} else if (selection.equals("Cylinder")) {
			dim1 = JOptionPane.showInputDialog("Enter the radius: ");
			dim2 = JOptionPane.showInputDialog("Enter the height: ");
			try {
				radius = Double.parseDouble(dim1);
				height = Double.parseDouble(dim2);
				shapePanel = new DrawShape(selection, new double[] { radius, height });
				rightPanel.add(shapePanel, BorderLayout.CENTER);

			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}
		} else if (selection.equals("Torus")) {
			dim1 = JOptionPane.showInputDialog("Enter the minor radius: ");
			dim2 = JOptionPane.showInputDialog("Enter the major Radius: ");
			try {
				radius = Double.parseDouble(dim1);
				height = Double.parseDouble(dim2);
				shapePanel = new DrawShape(selection, new double[] {radius, height });
				rightPanel.add(shapePanel, BorderLayout.CENTER);

			} catch (Exception ae) {
				JOptionPane.showMessageDialog(this, "Not valid input");
			}

		}
		setVisible(true);
	}

	public static void main(String[] args) {
		MainGUI gui = new MainGUI();
		gui.setVisible(true);

	}

}
