package shape_Project2;


import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
/**This class accepts radius and height and calculates volume of the Cylinder in terms radius r and height h, extends ThreeDimensionalShape class.
* @author Trupti Thakur */

public class Cylinder extends ThreeDimensionalShape {
	
	public Cylinder(double radius, double height) {
		super(radius, height);
	}
	
	/**
	 * getRadius method returns radius of the Cone.
	 * @return radius of the cylinder.
	 */
	
	
	public double getRadius() {
		return getDim1();
	}
	
	/**
	 * getHeight method returns height of the Cone.
	 * @return height of the cylinder.
	 */
	
	public double getHeight() {
		return getDim2();
	}

	/*@Override
	public double getArea() {
		return Math.pow(getRadius(), 2) * 6;
	}*/

	/**
	 * getVolume method calculates volume of the cylinder.
	 * @return volume of the cylinder.
	 */
	@Override
	public double getVolume() {
		return Math.PI * Math.pow(getRadius(), 2)* getHeight() ;
	}
	
	DecimalFormat myFormatter = new DecimalFormat("###.##");
	
	/**
	 * toString method
	 * @return A string containing a Cylinder's volume information.
	 */
	@Override
	public String toString() {
		String str = "Volume of the Cylinder:  "+ myFormatter.format(getVolume())+"\n";
		return str;
		
	}
	




}
